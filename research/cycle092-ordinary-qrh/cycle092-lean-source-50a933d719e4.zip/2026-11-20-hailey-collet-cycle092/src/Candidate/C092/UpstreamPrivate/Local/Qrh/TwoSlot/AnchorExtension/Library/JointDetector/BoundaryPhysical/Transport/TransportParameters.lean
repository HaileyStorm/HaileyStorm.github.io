/- Modified by Joseph Bebel (2026-11-12) for the 256-stage PR137 extension.
Imports are relocated into the private local fork. Where present, stage and return
parameters instantiate the frozen 0.87334664 extension. Original notices follow.
Pinned upstream: TheSil/QuasiRiemannTracker, 9d81a4c0b0e8338ef458f3ba5139657ae5404fde. -/
/- Copyright (c) 2026 Joseph Bebel. Apache-2.0.
Fixed positive row fee and conductor extension 1/10^22.
The support padding is half the extension; the later budget is reduced accordingly.
Inherited notices and source attribution follow unchanged. -/
/- Copyright (c) 2026 Joseph Bebel. Apache-2.0.
Fixed HIGH row fee 1/10^12, source reserve half that fee.
Contour extension 1/10^10 and support padding 5/10^11 are unchanged.
Inherited notices and preceding adapter attribution follow unchanged. -/
/- Copyright (c) 2026 Joseph Bebel. Apache-2.0.
Restart return: h < .813, y < .473, ell < .173, row fee 1e-22.
All numerical proof obligations are re-elaborated; inherited notices follow. -/
/- Copyright (c) 2026 Joseph Bebel. Apache-2.0.
Adapted for the fine-chain return: h < .810, floor reserve 1/10000.
All inherited notices follow unchanged; upstream source files are unmodified. -/
/- Repeated marks: fork of Collet's generic return module Transport.TransportParameters (Record1252270103Return,
Apache-2.0; inherited notices retained), re-elaborated in QRH.RepeatedMarks.Return against the
relaxed parameter bounds `Geometry.BoundsR`, with the physical face applied globally (Lemma D). -/
/- Physical full pre-height slot/phase transport schedule. Predecessor attribution retained. Apache-2.0. -/
/- Modified by Sil (2026-10-26): forked into QRH.SilDensitySplit.Return (namespaces and imports renamed);
re-elaborated against the widened coarse box `BoundsN` (873/1000<θ, h<806/1000, ell<171/1000) and,
where used, the physical slot cap as the `PhysicalSchedule` field `cap`. -/
/- Modified by Sil (2026-11-11): floor budget 1/100000 in `TransportParameters.floor_budget` (and its two proofs). -/
import Submissions.hailey_collet_1252270103.Record1252270103Return.GenericData
import Candidate.C092.UpstreamPrivate.Local.Qrh.TwoSlot.AnchorExtension.Library.JointDetector.BoundaryPhysical.TransportGeometry

set_option autoImplicit false
namespace Qrh.JointDetector.BoundaryPhysical.Return.GenericPhysical.Assembly
open QRH.Record1252270103Return QRH.Record1252270103Return.GenericPhysical
noncomputable section
variable [QRH.Record1252270103Return.Geometry.Parameters] [Qrh.JointDetector.BoundaryPhysical.Return.Geometry.CoreBounds]
open scoped Classical BigOperators
open QRH.Record1252270103Return.Geometry
open OAI.SevenEighths QRH.Record1252270103Return.GenericPhysical

/-- Reduce the contour spacing after the finite slot partition is fixed. -/
def withSmallerE (D : BaselineData) (e : ℝ) (he : 0< e) (hle : e≤ D.e) : BaselineData :=
  { D with
    e := e
    e_pos := he
    e_small := hle.trans_lt D.e_small
    detector_budget := by
      have hd:=D.detector_budget
      nlinarith }

theorem withSmallerE_length (D : BaselineData) (e : ℝ) (he : 0< e) (hle : e≤ D.e) :
    (withSmallerE D e he hle).length=D.length := rfl

def commonMesh (t : ℝ) : ℝ := min (Cycle25.sourceMesh t) t
lemma commonMesh_pos {t : ℝ} (ht : 0< t) : 0< commonMesh t :=
  lt_min (Cycle25.sourceMesh_pos ht) ht
lemma commonMesh_le {t : ℝ} : commonMesh t≤ t := min_le_right _ _

def rowPadding : ℝ := 1/2000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000

structure TransportParameters (D : BaselineData) where
  t_padding : D.t≤1/4000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
  mesh : ℝ
  mesh_pos : 0< mesh
  mesh_small : mesh≤ D.t
  slots_mesh : ∀j,D.length j≤ mesh/200
  e_tsmall : D.e≤ D.t/10000
  rmin : ℝ
  rmin_pos : 0< rmin
  slots_lower : ∀j,(7/8:ℝ)*rmin≤ D.length j
  ellMin : ℝ
  ellMin_pos : 0< ellMin
  slots_min : ∀j,ellMin≤ D.length j
  phaseEpsilon : ℝ
  phaseEpsilon_pos : 0< phaseEpsilon
  phaseKappa : ℝ
  phaseKappa_pos : 0< phaseKappa
  phase_budget : 8*D.e*D.t+phaseKappa≤ phaseEpsilon
  phase_gap : phaseEpsilon< rmin*mesh
  eps : ℝ
  eps_pos : 0< eps
  eps_budget : (D.N+8)*eps≤ D.t/100
  sigma : ℝ
  sigma_pos : 0< sigma
  sigma_small : sigma≤ D.t/8
  nu : ℝ
  nu_pos : 0< nu
  nu_eq : nu=D.t/8
  geometric_budget : sigma+8*D.e+nu≤1/20
  principal_budget : sigma+nu≤1/4000
  window_budget : sigma+D.e≤ QRH.Record1252270103Return.Geometry.theta*ellMin
  floor_budget : 26*D.e+(D.N+8)*eps+D.t+mesh*QRH.Record1252270103Return.Geometry.ell+nu+sigma≤1/100000

/-- All genuine baseline data and phase parameters are fixed before source or height. -/
theorem exists_compatible_data {κ budget : ℝ} (hk : 7/10≤κ) (hk1 : κ≤3/4)
    (hb : 0< budget) :
    ∃D : BaselineData,D.momentKappa=κ ∧ 159*D.ε+609*D.t≤ budget ∧
      (∀j,D.length j≤ Cycle25.sourceMesh D.t/200) ∧
      (∀j,D.length j≤ commonMesh D.t/200) ∧ Nonempty (TransportParameters D) := by
  let small : ℝ := min budget (1/10000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000)
  have hsmall : 0< small := lt_min hb (by norm_num)
  obtain ⟨D,hκ,hbudget,hfine,hcommon⟩ := exists_baseline_data_common_mesh hk hk1 hsmall
    commonMesh (fun _ ht=> commonMesh_pos ht)
  have hbound : 159*D.ε+609*D.t≤ budget := hbudget.trans (min_le_left _ _)
  have hsum : 0<∑j,D.length j := by rw [D.slots_sum];exact Geometry.ell_pos
  obtain ⟨j,_,_⟩ := (Finset.sum_pos_iff_of_nonneg (fun j _=>(D.slots_pos j).le)).mp hsum
  let : Nonempty (Fin D.N) := ⟨j⟩
  obtain ⟨m,hm,hmle⟩ : ∃m : ℝ,0< m ∧ ∀j,m≤ D.length j := by
    obtain ⟨i,hmle⟩ := Finite.exists_min D.length
    exact ⟨D.length i,D.slots_pos i,hmle⟩
  let mesh := commonMesh D.t
  have hmesh : 0< mesh := commonMesh_pos D.t_pos
  let phase := m*mesh/2
  have hphase : 0< phase := by positivity
  let e := min D.e (min (phase/(32*D.t)) (min (QRH.Record1252270103Return.Geometry.theta*m/4) (D.t/10000)))
  have htheta : 0< QRH.Record1252270103Return.Geometry.theta := by linarith [Qrh.JointDetector.BoundaryPhysical.Return.Geometry.CoreBounds.theta_bounds.1]
  have ht:=D.t_pos
  have hep : 0< e := lt_min D.e_pos (lt_min (by positivity) (lt_min (by positivity) (by positivity)))
  have heD : e≤ D.e := min_le_left _ _
  have hephase : e≤ phase/(32*D.t) := (min_le_right _ _).trans (min_le_left _ _)
  have hetheta : e≤ QRH.Record1252270103Return.Geometry.theta*m/4 :=
    (min_le_right _ _).trans ((min_le_right _ _).trans (min_le_left _ _))
  have hesmall : e≤ D.t/10000 :=
    (min_le_right _ _).trans ((min_le_right _ _).trans (min_le_right _ _))
  let D' := withSmallerE D e hep heD
  let sigma := min (QRH.Record1252270103Return.Geometry.theta*m/4) (D.t/8)
  have hsigma : 0< sigma := lt_min (by positivity) (by positivity)
  have hsigma1 : sigma≤ D.t/8 := min_le_right _ _
  have hsigmaw : sigma≤ QRH.Record1252270103Return.Geometry.theta*m/4 := min_le_left _ _
  let eps : ℝ := D.t/(100*(D.N+8))
  have heps : 0< eps := by positivity
  refine ⟨D',hκ,hbound,hfine,hcommon,⟨{
    t_padding:=by
      have hbsmall := hbudget.trans (min_le_right _ _)
      have hep0:=D.epsilon_pos
      change D.t≤1/4000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
      linarith
    mesh:=mesh
    mesh_pos:=hmesh
    mesh_small:=commonMesh_le
    slots_mesh:=hcommon
    e_tsmall:=hesmall
    rmin:=m
    rmin_pos:=hm
    slots_lower:=fun j=> by dsimp [D',withSmallerE];nlinarith [hmle j]
    ellMin:=m
    ellMin_pos:=hm
    slots_min:=hmle
    phaseEpsilon:=phase
    phaseEpsilon_pos:=hphase
    phaseKappa:=phase/4
    phaseKappa_pos:=by positivity
    phase_budget:=by
      have ht:=D.t_pos
      have hmul: e*(32*D.t)≤ phase := (le_div_iff₀ (by positivity)).mp hephase
      change 8*e*D.t+phase/4≤ phase
      nlinarith
    phase_gap:=by dsimp [phase];nlinarith [mul_pos hm hmesh]
    eps:=eps
    eps_pos:=heps
    eps_budget:=by change (D.N+8:ℝ)*eps≤ D.t/100;dsimp [eps];field_simp; norm_num
    sigma:=sigma
    sigma_pos:=hsigma
    sigma_small:=hsigma1
    nu:=D.t/8
    nu_pos:=by positivity
    nu_eq:=rfl
    geometric_budget:=by change sigma+8*e+D.t/8≤1/20;linarith [D.t_small]
    principal_budget:=by linarith [D.t_small]
    window_budget:=by change sigma+e≤ QRH.Record1252270103Return.Geometry.theta*m;linarith [mul_pos htheta hm]
    floor_budget:=by
      have ht:=D.t_small
      have hme:mesh≤ D.t:=commonMesh_le
      have hmes:mesh*QRH.Record1252270103Return.Geometry.ell≤ D.t := by
        have hel : QRH.Record1252270103Return.Geometry.ell≤1 := by linarith [Geometry.ell_lt_fifth]
        exact (mul_le_mul_of_nonneg_left hel hmesh.le).trans (by simpa using hme)
      have hepsmul : (D.N+8:ℝ)*eps=D.t/100 := by
        dsimp [eps];field_simp
      change 26*e+(D.N+8)*eps+D.t+mesh*QRH.Record1252270103Return.Geometry.ell+D.t/8+sigma≤1/100000
      rw [hepsmul]
      linarith }⟩⟩

theorem exists_compatible_data_with_mesh {κ budget : ℝ} (hk : 7/10≤κ) (hk1 : κ≤3/4)
    (hb : 0< budget) (extraMesh : ℝ → ℝ)
    (hExtra : ∀t : ℝ,0< t → 0< extraMesh t) :
    ∃D : BaselineData,D.momentKappa=κ ∧ 159*D.ε+609*D.t≤ budget ∧
      (∀j,D.length j≤ Cycle25.sourceMesh D.t/200) ∧
      (∀j,D.length j≤ commonMesh D.t/200) ∧
      (∀j,D.length j≤ extraMesh D.t/200) ∧ Nonempty (TransportParameters D) := by
  let small : ℝ := min budget (1/10000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000)
  have hsmall : 0< small := lt_min hb (by norm_num)
  obtain ⟨D,hκ,hbudget,hfine,hboth⟩ := exists_baseline_data_common_mesh hk hk1 hsmall
    (fun t => min (commonMesh t) (extraMesh t))
    (fun t ht => lt_min (commonMesh_pos ht) (hExtra t ht))
  have hcommon : ∀j,D.length j≤ commonMesh D.t/200 := fun j =>
    (hboth j).trans (div_le_div_of_nonneg_right (min_le_left _ _) (by norm_num))
  have hextra : ∀j,D.length j≤ extraMesh D.t/200 := fun j =>
    (hboth j).trans (div_le_div_of_nonneg_right (min_le_right _ _) (by norm_num))
  have hbound : 159*D.ε+609*D.t≤ budget := hbudget.trans (min_le_left _ _)
  have hsum : 0<∑j,D.length j := by rw [D.slots_sum];exact Geometry.ell_pos
  obtain ⟨j,_,_⟩ := (Finset.sum_pos_iff_of_nonneg (fun j _=>(D.slots_pos j).le)).mp hsum
  let : Nonempty (Fin D.N) := ⟨j⟩
  obtain ⟨m,hm,hmle⟩ : ∃m : ℝ,0< m ∧ ∀j,m≤ D.length j := by
    obtain ⟨i,hmle⟩ := Finite.exists_min D.length
    exact ⟨D.length i,D.slots_pos i,hmle⟩
  let mesh := min (commonMesh D.t) (extraMesh D.t)
  have hmesh : 0< mesh := lt_min (commonMesh_pos D.t_pos) (hExtra D.t D.t_pos)
  have hmeshsmall : mesh≤D.t := (min_le_left _ _).trans commonMesh_le
  let phase := m*mesh/2
  have hphase : 0< phase := by positivity
  let e := min D.e (min (phase/(32*D.t)) (min (QRH.Record1252270103Return.Geometry.theta*m/4) (D.t/10000)))
  have htheta : 0< QRH.Record1252270103Return.Geometry.theta := by linarith [Qrh.JointDetector.BoundaryPhysical.Return.Geometry.CoreBounds.theta_bounds.1]
  have ht:=D.t_pos
  have hep : 0< e := lt_min D.e_pos (lt_min (by positivity) (lt_min (by positivity) (by positivity)))
  have heD : e≤ D.e := min_le_left _ _
  have hephase : e≤ phase/(32*D.t) := (min_le_right _ _).trans (min_le_left _ _)
  have hetheta : e≤ QRH.Record1252270103Return.Geometry.theta*m/4 :=
    (min_le_right _ _).trans ((min_le_right _ _).trans (min_le_left _ _))
  have hesmall : e≤ D.t/10000 :=
    (min_le_right _ _).trans ((min_le_right _ _).trans (min_le_right _ _))
  let D' := withSmallerE D e hep heD
  let sigma := min (QRH.Record1252270103Return.Geometry.theta*m/4) (D.t/8)
  have hsigma : 0< sigma := lt_min (by positivity) (by positivity)
  have hsigma1 : sigma≤ D.t/8 := min_le_right _ _
  have hsigmaw : sigma≤ QRH.Record1252270103Return.Geometry.theta*m/4 := min_le_left _ _
  let eps : ℝ := D.t/(100*(D.N+8))
  have heps : 0< eps := by positivity
  refine ⟨D',hκ,hbound,hfine,hcommon,hextra,⟨{
    t_padding:=by
      have hbsmall := hbudget.trans (min_le_right _ _)
      have hep0:=D.epsilon_pos
      change D.t≤1/4000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
      linarith
    mesh:=mesh
    mesh_pos:=hmesh
    mesh_small:=hmeshsmall
    slots_mesh:=hboth
    e_tsmall:=hesmall
    rmin:=m
    rmin_pos:=hm
    slots_lower:=fun j=> by dsimp [D',withSmallerE];nlinarith [hmle j]
    ellMin:=m
    ellMin_pos:=hm
    slots_min:=hmle
    phaseEpsilon:=phase
    phaseEpsilon_pos:=hphase
    phaseKappa:=phase/4
    phaseKappa_pos:=by positivity
    phase_budget:=by
      have ht:=D.t_pos
      have hmul: e*(32*D.t)≤ phase := (le_div_iff₀ (by positivity)).mp hephase
      change 8*e*D.t+phase/4≤ phase
      nlinarith
    phase_gap:=by dsimp [phase];nlinarith [mul_pos hm hmesh]
    eps:=eps
    eps_pos:=heps
    eps_budget:=by change (D.N+8:ℝ)*eps≤ D.t/100;dsimp [eps];field_simp; norm_num
    sigma:=sigma
    sigma_pos:=hsigma
    sigma_small:=hsigma1
    nu:=D.t/8
    nu_pos:=by positivity
    nu_eq:=rfl
    geometric_budget:=by change sigma+8*e+D.t/8≤1/20;linarith [D.t_small]
    principal_budget:=by linarith [D.t_small]
    window_budget:=by change sigma+e≤ QRH.Record1252270103Return.Geometry.theta*m;linarith [mul_pos htheta hm]
    floor_budget:=by
      have ht:=D.t_small
      have hme:mesh≤ D.t:=hmeshsmall
      have hmes:mesh*QRH.Record1252270103Return.Geometry.ell≤ D.t := by
        have hel : QRH.Record1252270103Return.Geometry.ell≤1 := by linarith [Geometry.ell_lt_fifth]
        exact (mul_le_mul_of_nonneg_left hel hmesh.le).trans (by simpa using hme)
      have hepsmul : (D.N+8:ℝ)*eps=D.t/100 := by
        dsimp [eps];field_simp
      change 26*e+(D.N+8)*eps+D.t+mesh*QRH.Record1252270103Return.Geometry.ell+D.t/8+sigma≤1/100000
      rw [hepsmul]
      linarith }⟩⟩


theorem padding_budget (D : BaselineData) (P : TransportParameters D) :
    rowPadding+2*D.t≤ Qrh.JointDetector.BoundaryPhysical.TransportKernel.Transport.Transport.rowExtension := by
  have h:=P.t_padding
  norm_num [QRH.Record1252270103Return.Geometry.theta,QRH.Record1252270103Return.Geometry.h,QRH.Record1252270103Return.Geometry.ell,QRH.Record1252270103Return.Geometry.x,QRH.Record1252270103Return.Geometry.y,rowPadding,Qrh.JointDetector.BoundaryPhysical.TransportKernel.Transport.Transport.rowExtension] at *
  linarith

theorem padded_row_cutoff (D : BaselineData) (P : TransportParameters D) :
    QRH.Record1252270103Return.Geometry.h+rowPadding+2*D.t≤ Qrh.JointDetector.BoundaryPhysical.Return.Geometry.dPlus := by
  change QRH.Record1252270103Return.Geometry.h+rowPadding+2*D.t≤ QRH.Record1252270103Return.Geometry.h+1/1000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000
  have h:=padding_budget D P
  dsimp [Qrh.JointDetector.BoundaryPhysical.TransportKernel.Transport.Transport.rowExtension] at h
  linarith
end
end Qrh.JointDetector.BoundaryPhysical.Return.GenericPhysical.Assembly

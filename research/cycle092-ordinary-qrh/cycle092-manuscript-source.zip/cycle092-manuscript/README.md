# Cycle092 proof edition

Hailey Collet · HaileyCollet@gmail.com

This is the complete public proof **The ordinary QRH half-plane: a compact working proof**, with a dated formalization supplement (20 November 2026 UTC). The exact result is c=63333603/500000000=.126667206 and theta=436666397/500000000=.873332794, in the strict half-plane with the actual principal pole excluded. The scope includes every ordinary character at every fixed positive presented modulus, including imprimitive presentations and all finite heights; it asserts no boundary-line result or uniformity in growing moduli.

- `Cycle092-proof.pdf`: complete typeset edition.
- `Cycle092-proof.tex`: standalone TeX source; all proof and supplement inputs are expanded into this file.
- `main.tex`, `proof-body.tex`, `formalization-supplement.tex`: the equivalent editable local project.
- `public-source/packet/CLOSED_PROOF.md`: unchanged canonical public Markdown (SHA-256 c1876d05ad7376e6b9ecf91005b6be496d061b304cfd598adb54ac2603f87247).
- `public-source/`: unchanged submitted written-proof package, including exact finite certificates, source manifest, checksums and `replay.py`. Its README records the historical written-submission status; the later local formalization status is recorded separately in the dated supplement and `local-verification.json`.
- `typesetting-fidelity.json`: reader settings, math-node and heading counts, link audit, and typesetting-only repairs needed to render the original Markdown math as TeX.
- `edition-checks.json` and `SHA256SUMS`: edition validation and file identities.

The authentic written source is pinned at [commit 1affb4664d550a568e32be35238445e3831ed237](https://github.com/HaileyStorm/quasi-rh-hillclimb/tree/1affb4664d550a568e32be35238445e3831ed237/submissions/hailey-collet-cycle092), submitted in [written PR45](https://github.com/rohanarun/quasi-rh-hillclimb/pull/45). The complete proof and inherited attribution are retained. The source's historical statements remain in place; no later hosted acceptance is implied.

The local Lean 4.34.1 final root was compiled unconditionally from source against development dependency objects and checked separately for the exact all-Dirichlet signature and the standard axiom list. This edition does not claim a complete clean submission build, canonical independent kernel replay, or protected tracker acceptance. See the supplement and the sanitized source-bound receipt `local-verification.json`.

Compile the standalone file with XeLaTeX or Tectonic, for example `tectonic Cycle092-proof.tex`. The checked edition used pinned Tectonic 0.17.0 with its cached version-33 bundle. Its source uses standard AMS, Latin Modern, table, graphics and hyperref packages. The editable project compiles through `main.tex`; no editor tab needs to be opened or replaced. The source ZIP contains the TeX project, standalone TeX, notices, validation data, and unchanged public written-proof/certificate package; the PDF is supplied separately.

Copyright 2026 Hailey Collet. New material is Apache-2.0; inherited work retains its original authorship, licences and notices. See `LICENSE`, `NOTICE.md`, and the manuscript's original attribution. Hailey Collet is the sole human author of this contribution. Research, drafting and code development were substantially AI-assisted; AI assistance is not independent verification.
